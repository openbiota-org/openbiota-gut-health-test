#!/usr/bin/env python3
"""Bounded, read-only access to the OpenBiota intervention data snapshot."""
import argparse,json,sqlite3
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--db',type=Path,default=Path(__file__).with_name('openbiota_intervention_data.sqlite'))
s=p.add_subparsers(dest='command',required=True)
q=s.add_parser('tables');q.add_argument('--match',default='')
q=s.add_parser('search');q.add_argument('terms');q.add_argument('--limit',type=int,default=8)
q=s.add_parser('record');q.add_argument('id')
q=s.add_parser('rows');q.add_argument('table_id');q.add_argument('--offset',type=int,default=0);q.add_argument('--limit',type=int,default=8)
q=s.add_parser('sources');q.add_argument('--match',default='')
q=s.add_parser('notes');q.add_argument('terms');q.add_argument('--limit',type=int,default=5)
q=s.add_parser('object');q.add_argument('id')
a=p.parse_args();db=sqlite3.connect(a.db.resolve().as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
def emit(rows):
 for row in rows:
  d=dict(row)
  for k in list(d):
   if k.endswith('_json'):
    d[k[:-5]]=json.loads(d.pop(k))
  print(json.dumps(d,ensure_ascii=False))
def limit(n):return max(1,min(n,50))
if a.command=='tables':
 emit(db.execute('SELECT table_id,section_path,headers_json,row_count FROM data_tables WHERE section_path LIKE ? ORDER BY source_line',('%'+a.match+'%',)))
elif a.command=='search':
 emit(db.execute("SELECT record_id,legacy_id,section_path,snippet(records_fts,3,'[',']',' … ',32) AS excerpt FROM records_fts WHERE records_fts MATCH ? ORDER BY rank LIMIT ?",(a.terms,limit(a.limit))))
elif a.command=='record':
 emit(db.execute('SELECT r.record_id,r.legacy_id,r.table_id,t.section_path,r.source_line,r.fields_json FROM records r JOIN data_tables t USING(table_id) WHERE record_id=? OR legacy_id=? ORDER BY r.source_line LIMIT 50',(a.id,a.id)))
elif a.command=='rows':
 emit(db.execute('SELECT record_id,legacy_id,source_line,fields_json FROM records WHERE table_id=? ORDER BY row_index LIMIT ? OFFSET ?',(a.table_id,limit(a.limit),max(0,a.offset))))
elif a.command=='sources':
 emit(db.execute('SELECT catalog_id,catalog_family,name,source_urls_json,metadata_json FROM source_catalog WHERE name LIKE ? OR metadata_json LIKE ? ORDER BY catalog_id',('%'+a.match+'%','%'+a.match+'%')))
elif a.command=='notes':
 emit(db.execute('SELECT block_id,section_path,start_line,end_line,substr(text,1,2200) AS excerpt FROM source_blocks WHERE text LIKE ? ORDER BY start_line LIMIT ?',('%'+a.terms+'%',limit(a.limit))))
elif a.command=='object':
 emit(db.execute('SELECT object_id,section_path,source_line,value_json FROM structured_objects WHERE object_id=?',(a.id,)))
db.close()
