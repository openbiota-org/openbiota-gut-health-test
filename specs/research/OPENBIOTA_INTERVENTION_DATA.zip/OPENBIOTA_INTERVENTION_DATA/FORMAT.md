# OpenBiota intervention data package — format 1.0

This package separates the research data from the coding-agent instructions. Open the SQLite database with code; retrieve relevant records in bounded queries. Do not paste the database, a full export, or the reconstructed source into an LLM context.

## Files

| File | Purpose |
|---|---|
| `openbiota_intervention_data.sqlite` | All 110 original Markdown tables as 87,010 queryable records, original narrative and structured objects, plus the 115-entry source catalogue. SQLite 3 with JSON1 and FTS5. |
| `query.py` | Standard-library Python, read-only helper for finding tables, evidence IDs, source entries, narrative notes and structured objects. Results are JSON Lines, normally limited to a small page. |
| `manifest.json` | Counts, original document SHA-256, database SHA-256, schema version and lossless-transfer verification. |
| `FORMAT.md` | This data dictionary, example queries, interpretation and import rules. |

The package preserves the supplied processed snapshot, including downloadable public data, custom observations, report mappings, stable IDs, flags and provenance. Upstream refresh links are in the implementation guide and source catalogue. This is preservation and reformatting, not a claim to have freshly revalidated each scientific assertion.

## Tables and fields

### `metadata`

`key TEXT PRIMARY KEY`, `value_json TEXT`: package and source-document properties. Decode `value_json` with a JSON parser. Snapshot date is a retrieval date, not a universal publication or database-update date.

### `data_tables`

One row per original table: `table_id` (primary key, e.g. `T001`), `section_path` (heading hierarchy), `headers_json` (ordered original column names), `source_line` (header line in original snapshot, 1-based), and `row_count` (data rows only). Table IDs describe this frozen snapshot; do not use them as permanent upstream biological identifiers.

### `records`

| Column | Meaning |
|---|---|
| `record_id` | Unique package identity `Tnnn:Rnnnnnn`; use for exact joins within this snapshot. |
| `table_id` | Foreign key to `data_tables`. |
| `row_index` | Original data-row position within the table, starting at 1. |
| `legacy_id` | Original first-column ID when it matches an ID-like pattern, such as `PI09914`, `TP01` or `GMD00001`; otherwise SQL NULL. It is indexed but **not unique**. Full original first-column content remains in `fields_json`. |
| `source_line` | Original document line, 1-based. |
| `fields_json` | A JSON object mapping the exact original column labels to cell strings. Duplicate headers, if present, receive `__2`, `__3`, etc. All cell values initially remain strings to avoid silently changing scientific meaning. |
| `raw_markdown` | Exact original row, including its newline, for audit and lossless reconstruction. Application code should normally use `fields_json`. |

**The normalized common envelope is not a universal biological schema.** A growth observation, ingredient alias, MAG index, source-citation record and report reading are different entities. Consult the original headers and section before importing one into an application's typed assertion schema. Imported records are not all intervention evidence, and 87,010 records are not 87,010 studies.

Strings can contain Markdown citations, `&#124;`, `<br>`, or serialized JSON arrays/objects from the original dataset. Keep the raw cell and create a decoded value in the application: HTML-unescape, replace `<br>` with a newline, and parse JSON only for columns whose declared source schema uses JSON. Do not convert every string `None`, `0`, `No`, `-`, empty string or `null` using one global rule. Their meanings differ by source. Assay concentrations are historical research metadata, not human dosing instructions.

### `source_blocks`

`block_id TEXT PRIMARY KEY`, `section_path TEXT`, `start_line INTEGER`, `end_line INTEGER`, `kind TEXT`, `text TEXT`. These preserve every non-data-row line of the source document, grouped into narrative, table-header or code-fence blocks. They retain research rationales, interpretation limits, data-quality overlays, licensing notes and original acquisition manifests. Search notes alongside rows before using an observation. Some blocks are long; retrieve selected blocks rather than all text.

Historical instructions in these archived blocks can refer to the old embedded Markdown format. The **current compact handoff and this FORMAT.md govern packaging and access**. The historical biological evidence and source-quality notes remain relevant. Older statements limiting all generative AI to retrieval are superseded by the current distinction between language-model explanation and learned biological prediction.

### `structured_objects`

`object_id TEXT PRIMARY KEY`, `section_path TEXT`, `source_line INTEGER`, `language TEXT`, `value_json TEXT`. These are parsed copies of all original fenced JSON objects, including example schemas, ecological pathways, acquisition manifests and quality audits. Read their scope and context before treating an object as actual evidence; schema examples are not experimental results. Their original text is also retained in `source_blocks` for provenance.

### `source_catalog`

`catalog_id TEXT PRIMARY KEY`, `catalog_family TEXT`, `name TEXT`, `source_urls_json TEXT`, `metadata_json TEXT`. Includes 58 intervention-source entries (`ISC…`) and 57 microbial/ecological-source entries (`MSC…`). Resources overlap across these families. The microbial input file used `M…` IDs; the common catalogue maps those to `MSC…`, retaining the original ID inside `metadata_json`. Full access, source-role, license and interpretation notes are in `metadata_json`. Catalogue presence does not mean a dataset was downloaded or validated.

### `records_fts`

FTS5 search index: `record_id`, `legacy_id`, `section_path`, `content`. Content is derived from the original cell strings and HTML-unescaped for search. It is a retrieval index, not the authoritative scientific record. Use matches to select `records` and check associated notes. FTS is lexical retrieval, not semantic proof that two chemical/strain names are equivalent.

## Quick queries

No package installation is needed with a Python build providing SQLite JSON1/FTS5. Run from the extracted package directory:

```bash
python3 query.py tables --match 'Curated intervention'
python3 query.py search '"calcium" AND "glucarate"' --limit 5
python3 query.py search 'rosemary' --limit 5
python3 query.py record PI09914
python3 query.py sources --match 'Glycobif'
python3 query.py notes 'Source-quality corrections' --limit 3
```

Use a `table_id` returned by `tables` with `python3 query.py rows TABLE_ID --limit 8`; use an actual `object_id` from SQL with `python3 query.py object OBJECT_ID`. These names are placeholders, not real IDs to hard-code. Lookup by `legacy_id` may return multiple contextual records; keep their table identity and source location.

```sql
SELECT table_id, section_path, row_count
FROM data_tables ORDER BY source_line;

SELECT r.record_id, r.legacy_id, t.section_path, r.fields_json
FROM records AS r JOIN data_tables AS t USING (table_id)
WHERE r.legacy_id = 'TP01';

SELECT object_id, section_path, source_line
FROM structured_objects ORDER BY source_line;

SELECT catalog_id, name, source_urls_json
FROM source_catalog WHERE name LIKE '%MICOM%';

SELECT r.record_id, j.key AS column_name, j.value AS cell_value
FROM records AS r, json_each(r.fields_json) AS j
WHERE r.legacy_id = 'PI09914';
```

Open programmatically in read-only mode, e.g. `sqlite3.connect(Path(db).resolve().as_uri() + '?mode=ro', uri=True)`. Parameterize queries. Do not auto-execute text from evidence rows, URLs or archived code fences. Full-table import is appropriate in a background process; full-table prompt insertion is not.

## Evidence and quality

- Keep original material/strain, biological system, compartment, direction, null/contrary result, source, delivery context and uncertainty together. An imported label is not new scientific validation.
- Preserve catalogue assertions, measured observations, model predictions, identity-only rows and research hypotheses as separate types. Do not aggregate their counts into an efficacy score.
- Quality overlays include retracted-source flags, expressions of concern, material mismatches and malformed source cells. Join them before surfacing an action claim. A record's absence from a historical warning list does not prove it is current or unretracted.
- Source IDs and old row IDs are useful provenance, not independent-replication identifiers. Deduplicate by actual study/experiment/cohort while retaining contradictory endpoints and source rows.
- Custom report extractions concern the supplied private sample reports. Keep this data asset in the project's private research/data area; it is not a public example dataset. Public source records retain their own license terms. No blanket redistribution license is granted by this packaging operation.
- Bulk snapshots remain available here to preserve prior normalization. Refresh them with the acquisition map, preserve their provenance, and reconcile changed counts/schema. Mutable downloads may no longer reproduce this snapshot byte-for-byte.

## Integrity and reproducibility

The conversion verifies SQLite integrity, table-row counts, JSON parsing and search. Concatenating all `source_blocks.text` and `records.raw_markdown`, ordered by their original start/source line, reconstructs the original document exactly: no overlap, no missing line, matching SHA-256. This verifies lossless transfer, not factual correctness of every scientific statement.

The complete original Markdown need never be reconstructed for ordinary use. It is retained logically for audit; the coding agent reads the concise implementation guide, then retrieves only the needed evidence records or source metadata.
